@extends('home_landing_page')

@section('home_content')
    <!--hero header-->
    <section class="pt-7 pt-md-8" id="home">
        <div class="container">
            <div class="row">
                <div class="col-md-8 mx-auto my-auto text-center">
                    <h1> Bangladesh Institute of Health Sciences Hospital </h1>
                    <p class="lead mt-4 mb-5">
                        Welcome to Bangladesh Institute of Health Sciences General Hospital
                    </p>
                    {{-- <p><img class="img-fluid" src="{{ asset('assets/frontend/img/26363.jpg') }}" alt="Mockup" /></p> --}}
                </div>
            </div>
        </div>
    </section>
@endsection
